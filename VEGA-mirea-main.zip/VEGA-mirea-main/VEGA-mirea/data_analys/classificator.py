import os
class classificator:
    def __init__(self, pathToFiles, pathToThemes, outputPath):
        self.pathToFiles = pathToFiles
        self.pathToThemes = pathToThemes
        self.outputPath = outputPath
        self.themesSlovar = self.countPercentage(self.pathToThemes)
        self.fileSlovar = self.countPercentage(self.pathToFiles)
        self.findTheme(self.fileSlovar, self.themesSlovar, self.outputPath)


    def countPercentage(self, files):
        self.directory = {}
        for fileName, directory in files.items():
            self.dir = {}
            self.k = 0
            for word, count in directory.items():
                self.k += float(count)
            for word,count in directory.items():
                self.dir[word] = "{:.4f}".format(float(count) / self.k * 1000)
            self.directory[fileName] = self.dir
        return self.directory


    def findTheme(self, files, themes, output):
        self.classificators = open(os.path.join(output, "classificator.txt"), "w", encoding="utf8")
        for fileName, fileDir in files.items():
            self.k = 0
            self.name = ""
            for themeName, themeDir in themes.items():
                self.s = 0
                for fileword, filePercents in fileDir.items():
                    for themeword, themePercents in themeDir.items():
                        if themeword == fileword:
                            self.s += float(filePercents) * float(themePercents)
                if self.s > self.k:
                    self.k = self.s
                    self.name = themeName
            if fileName[-4:] == ".txt": fileName = fileName[:-4]
            self.classificators.write(f"{fileName}\t{self.name}\n")
        self.classificators.close()