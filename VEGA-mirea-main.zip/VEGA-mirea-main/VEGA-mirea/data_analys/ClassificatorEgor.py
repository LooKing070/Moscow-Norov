'''

НЕ ТРОГАТЬ НАХУЙ, ИНАЧЕ УЕБУ 2

'''
#from themes_analysing import folder
#from files_analysing import folder_themes
'''for file in folder: #обработка каждого файла
    for theme_file in folder_themes: #обработка каждой темы'''
