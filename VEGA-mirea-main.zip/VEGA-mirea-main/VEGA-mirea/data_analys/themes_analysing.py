'''

НЕ ТРОГАТЬ НАХУЙ, ИНАЧЕ УЕБУ

'''
from files_analysing import normalize_and_count_words
from files_analysing import write_normalized_words_to_file
from files_analysing import text_cleaner
import os
import re
import sys
import pymorphy2
import shutil
import nltk
morph = pymorphy2.MorphAnalyzer()
lemmatizer = nltk.WordNetLemmatizer()
dirtdir = os.path.dirname(os.path.abspath(__file__))

#определение Window, Linux, Mac
if "\\" in dirtdir:
    dirtdir = dirtdir.split("\\")
    dir = str(dirtdir[0]) + "\\"
else:
    dirtdir = dirtdir.split("/")
    dir = "/"
for x in dirtdir[1:-1]:
    dir = os.path.join(dir, x)

# блок взятия из UI папки, выбранной пользователем
sys.path.insert(1, dir)
from UI.UI import * #инициализация функций других файлов в системе
uin=UI()
pathToThemes = uin.getFolderPath() #взять от эрика путь к папке с темами
pathToOutputThemes=os.path.join(pathToThemes, "output") #путь к outputThemes
folder_themes = os.listdir(pathToThemes) #лист файлов в директории отданной эриком
stopwordsfile = os.path.join(dir, "templates", "stopwords.txt")
stopwords = open(stopwordsfile, 'r', encoding="utf8") #открытие стопвордов
stopwords = stopwords.readlines()
stopwords = [x[:-1] for x in stopwords]
if os.path.exists(pathToOutputThemes): #если папка с рабочими файлами есть, то она удаляется
    shutil.rmtree(pathToOutputThemes)
os.mkdir(pathToOutputThemes) #путь от папки

for theme_file in folder_themes: #обработка каждого файла
    try:
        f = open(os.path.join(pathToThemes, theme_file), 'r+', encoding="utf8") #открытие файла
        text_themes = f.read()
        clean_text_themes = text_cleaner(text_themes).lower()
        write_normalized_words_to_file(normalize_and_count_words(clean_text_themes), os.path.join(pathToOutputThemes, theme_file))
        f.close()
    except: pass