import os
import re
import sys
import pymorphy2
import shutil
import nltk
morph = pymorphy2.MorphAnalyzer()
lemmatizer = nltk.WordNetLemmatizer()
dirtdir = os.path.dirname(os.path.abspath(__file__))

#определение Window, Linux, Mac
if "\\" in dirtdir:
    dirtdir = dirtdir.split("\\")
    dir = str(dirtdir[0]) + "\\"
else:
    dirtdir = dirtdir.split("/")
    dir = "/"
for x in dirtdir[1:-1]:
    dir = os.path.join(dir, x)

# блок взятия из UI папки, выбранной пользователем
sys.path.insert(1, dir)
from UI.UI import * #инициализация функций других файлов в системе
uin=UI()
pathToTexts = uin.getFolderPath() #взять от эрика путь к папке
pathToOutput=os.path.join(pathToTexts, "output") #путь к output
folder = os.listdir(pathToTexts) #лист файлов в директории отданной эриком
stopwordsfile = os.path.join(dir, "templates", "stopwords.txt")
stopwords = open(stopwordsfile, 'r', encoding="utf8") #открытие стопвордов
stopwords = stopwords.readlines()
stopwords = [x[:-1] for x in stopwords]
if os.path.exists(pathToOutput): #если папка с рабочими файлами есть, то она удаляется
    shutil.rmtree(pathToOutput)
os.mkdir(pathToOutput) #путь от папки

def text_cleaner(text): #чистка текста от
    # создаем регулярное выражение для удаления лишних символов
    regular = r'[\“+\”+\!+\*+\#+\№\"\-+\+\=+\?+\&\^\.+\;\,+\>+\(\)\/+\:\\+\'+\~+\`+\—+\%+\$+\«+\»+0-9+\{+\}+\[+\]+\_+\–+\|+\<+\>+\„+\.+\,+\/]'
    # удаляем лишние символы
    text = re.sub(regular, ' ', text)
    return text # возвращаем очищенные данные
def normalize_and_count_words(input_text): #лемматизация
    normalized_words = [morph.parse(lemmatizer.lemmatize(word))[0].normal_form if len(word) > 2 else word for word in input_text.split()]
    slovar_s_kolvom = {word: normalized_words.count(word) for word in set(normalized_words)}
    return slovar_s_kolvom
def write_normalized_words_to_file(input_text, file_path):
    with open(file_path+".txt", 'w', encoding="utf8") as file:
        for word, count in input_text.items():
            if word not in stopwords:
                file.write(f'{word} \t {count}\n')


for file in folder: #обработка каждого файла
    try:
        f = open(os.path.join(pathToTexts, file), 'r+', encoding="utf8") #открытие файла
        text = f.read()
        clean_text = text_cleaner(text).lower()
        write_normalized_words_to_file(normalize_and_count_words(clean_text), os.path.join(pathToOutput, file))
        f.close()
    except:
        pass