import os
import re
import pymorphy2
import shutil
import nltk
nltk.download("wordnet")

class Analiser:
    def __init__(self, pathToTexts, dir):
        self.dirtdir = os.path.dirname(os.path.abspath(__file__))
        self.morph = pymorphy2.MorphAnalyzer()
        self.lemmatizer = nltk.WordNetLemmatizer()

        self.pathToTexts = pathToTexts
        self.folder=os.listdir(self.pathToTexts)
        self.stopwordsfile = os.path.join(dir, "templates", "stopwords.txt")

        self.stopwords = open(self.stopwordsfile, 'r', encoding="utf8")  # открытие стопвордов
        self.stopwords = self.stopwords.readlines()
        self.stopwords = [x[:-1] for x in self.stopwords]
        self.dictionary = {}
        for file in self.folder:  # обработка каждого файла
            try:
                self.f = open(os.path.join(pathToTexts, file), 'r', encoding="utf8")  # открытие файла
                self.text = self.f.read()
                self.clean_text = self.text_cleaner(self.text).lower()
                self.dictionary[file] = self.normalize_and_count_words(self.clean_text)
                self.f.close()
            except:
                pass


    def getDictionary(self):
        return (self.dictionary)


    def text_cleaner(self,text):  # чистка текста от
        # создаем регулярное выражение для удаления лишних символов
        regular = r'[\“+\”+\!+\*+\#+\№\"\-+\+\=+\?+\&\^\.+\;\,+\>+\(\)\/+\:\\+\'+\~+\`+\—+\%+\$+\«+\»+0-9+\{+\}+\[+\]+\_+\–+\|+\<+\>+\„+\.+\,+\/]'
        # удаляем лишние символы
        text = re.sub(regular, ' ', text)
        return text  # возвращаем очищенные данные

    def normalize_and_count_words(self, input_text):  # лемматизация
        normalized_words = [self.morph.parse(self.lemmatizer.lemmatize(word))[0].normal_form if len(word) > 2 else word for word in input_text.split()]
        slovar_s_kolvom = {word: normalized_words.count(word) for word in set(normalized_words) if word not in self.stopwords}
        return dict(sorted(slovar_s_kolvom.items(), key=lambda x: x[1], reverse = True))

    def write_normalized_words_to_file(self, dictionary, outputPath):
        for fileName, collection in dictionary.items():
            with open(os.path.join(outputPath, fileName) + ".txt", 'w', encoding="utf8") as file:
                for word, count in collection.items():
                    file.write(f"{word}\t{count}\n")
