from Data_analys.Analiser import *
from Data_analys.classificator import *
import tkinter as tk
from tkinter import ttk, filedialog
from tkinter.messagebox import showerror, showinfo

root = tk.Tk()
root.title('NLP 3000 +Ultra')
root.resizable(False, False)
root.geometry('600x150')



pathToTexts=""
pathToAnalysedText=""
pathToThemes=""
outputPath=""
dir = os.path.dirname(os.path.abspath(__file__))
def doBoth():
    if(pathToTexts=='' or pathToThemes=='' or outputPath == ""):
        showerror(title="Error", message="Empty Path")
        return
    showinfo("Info", "Process started")
    analiseFiles = Analiser(pathToTexts, dir)
    os.mkdir(os.path.join(outputPath, "normalized files"))
    analiseFiles.write_normalized_words_to_file(analiseFiles.getDictionary(), os.path.join(outputPath, "normalized files"))
    analiseThemes = Analiser(pathToThemes, dir)
    classificator(analiseFiles.getDictionary(), analiseThemes.getDictionary(), outputPath)
    showinfo("Info", "Process ended")

def second_task():
    if (pathToAnalysedText == '' or pathToThemes=='' or outputPath == ""):
        showerror(title="Error", message="Empty Path")
        return
    showinfo("Info", "Process started")
    analiseThemes = Analiser(pathToThemes, dir)
    filesDir = {}
    folder = os.listdir(pathToAnalysedText)
    for file in folder:
        filesDirq = {}
        openedFile = open(os.path.join(pathToAnalysedText, file), "r", encoding="utf8")
        r = openedFile.readlines()
        for line in r:
            filesDirq[line.split()[0]] = line.split()[1]
        filesDir[file] = dict(sorted(filesDirq.items(), key=lambda x: x[1], reverse = True))
    classificator(filesDir, analiseThemes.getDictionary(), outputPath)
    showinfo("Info", "Process ended")

def first_task():
    if (pathToTexts == '' or outputPath == ""):
        showerror(title="Error", message="Empty Path")
        return
    showinfo("Info", "Process started")
    a = Analiser(pathToTexts,dir)
    os.mkdir(os.path.join(outputPath, "normalized files"))
    a.write_normalized_words_to_file(a.getDictionary(), os.path.join(outputPath, "normalized files"))
    showinfo("Info", "Process ended")

def selectPathToText():
    global pathToTexts
    pathToTexts = filedialog.askdirectory(
        initialdir='/',
        title="Select Folder",
    )
    file_label.config(text=pathToTexts)


def selectPathToAnalysedText():
    global pathToAnalysedText
    pathToAnalysedText = filedialog.askdirectory(initialdir='/', title="Select Folder")
    analyzed_file_label.config(text=pathToAnalysedText)


def selectPathToThemes():
    global pathToThemes
    pathToThemes = filedialog.askdirectory(initialdir='/', title="Select Folder")
    themes_label.config(text=pathToThemes)

def selectOutputPath():
    global outputPath
    outputPath = filedialog.askdirectory(initialdir='/', title="Select Folder")
    output_label.config(text=outputPath)

#Кнопки выбора пути
open_button = ttk.Button(
    root,
    text='Open Files',
    command=selectPathToText
)

open_ready_button = ttk.Button(
    root,
    text='Open Analyzed Files',
    command=selectPathToAnalysedText
)

open_theme_button = ttk.Button(
    root,
    text='Open Themes',
    command=selectPathToThemes
)

select_output_button = ttk.Button(
    root,
    text='Select Output',
    command=selectOutputPath
)

#Кнопки выполнения задания
first_task_button = ttk.Button(
    root,
    text='Analyze texts',
    command=first_task
)

second_task_button = ttk.Button(
    root,
    text='Classificate analyzed texts',
    command=second_task
)

overall_button = ttk.Button(
    root,
    text='Do both',
    command=doBoth
)

#Текст
file_label = ttk.Label(master=root)
analyzed_file_label= ttk.Label(master=root)
themes_label = ttk.Label(master=root)
output_label = ttk.Label(master=root)


#Размещение
#--Кнопки выбора файлов
open_button.place(x=20,y=5)
open_ready_button.place(x=20,y=33)
open_theme_button.place(x=20,y=61)
select_output_button.place(x=20,y=90)
#--Кнопки запуска
first_task_button.place(x=50,y=120)
second_task_button.place(x=250,y=120)
overall_button.place(x=465,y=120)
#--Текст
file_label.place(x=150,y=10)
analyzed_file_label.place(x=150,y=33)
themes_label.place(x=150,y=63)
output_label.place(x=150,y=94)

root.mainloop()
