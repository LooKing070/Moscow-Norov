print("x y z w")
for x in range(2):
    for y in range(2):
        for z in range(2):
            for w in range(2):
                if ((x or z) <= (y and x)) and ((w == z) or (w <= (not(y)))) == 1:
                    print(x,y,z,w)