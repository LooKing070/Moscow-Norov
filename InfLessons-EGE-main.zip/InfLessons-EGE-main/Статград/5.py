k = 0
for x in range(100000000, 999999999):
    b = set()
    for w in str(x):
        b.add(w)
    k += len(b)
print(k)