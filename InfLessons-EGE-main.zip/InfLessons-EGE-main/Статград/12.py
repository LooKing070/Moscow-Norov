def f(x,a):
    return (x & 57665 == 0) <= ((x & 83265 != 0) <= (x&a != 0))

k = 0
for a in range(1, 2**20):
    if all(f(x,a) == 1 for x in range(2000)):
        k+=1
print(k)