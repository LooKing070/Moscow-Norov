f = open("/Users/andrej/Downloads/17.txt", "r")
a = [int(x) for x in f.readlines()]
k = 0
ma = 0
for x in range(len(a) - 4):
    q = a[x]
    w = a[x+1]
    e = a[x+2]
    r = a[x+3]
    s = [q,w,e,r]
    k7 = 0
    k5 = 0
    d5 = 0
    d3 = 0
    f = []
    for d in s:
        if 10000<= d <= 99999: d5 += 1
        if 100 <= d <= 999: d3 += 1
        if d % 5 == 0: k5 += 1
        if d % 7 == 0: k7 += 1
        if d % 1000 == 821: f.append(d)
    if len(f) == 0:
        pass
    else:
        if sum(s) > 2 * (min(f) + max(f)):
            k += 1
            ma = max(ma, sum(s))
print(k, ma)