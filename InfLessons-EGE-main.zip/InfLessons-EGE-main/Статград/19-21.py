from sys import *
setrecursionlimit(100000)
def kr(x):
    a = []
    for q in range(2, x + 1):
        if x % q == 0:
            a.append(x // q)
    return a
def f(s, m):
    a = kr(s)
    if s < 13 and m == 3: return 1
    elif s < 13 and m != 3: return 0
    elif m >3: return 0
    else:
        if len(a) > 0:
            if m % 2 == 0:
                q = f(s - (a.pop(0)),m + 1)
                for x in a:
                    q = q and f(s - x, m+1)
                return q
            else:
                q = f(s - (a.pop(0)), m + 1)
                for x in a:
                    q = q or f(s - x, m + 1)
                return q
        else: return 0

k=0
for x in range(13, 5000):
    if f(x, 0) == 1:
        print(x)