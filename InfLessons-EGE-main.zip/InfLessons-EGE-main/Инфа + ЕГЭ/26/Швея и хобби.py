for x in range(10, 30000):
    b = [q for q in str(x)]
    w = []
    for q in range(len(b)-1):
        w.append(int(b[q]) * 10 + int(b[q + 1]))
    if max(w) - min(w) == 44:
        print(x)
        break