f = open("/Users/andrej/Downloads/EGE-2024/26/car.txt", "r")
kol, maxprice = map(int, f.readline().split())
a = []
for x in f.readlines():
    tip, price = map(int, x.split())
    a.append([tip, price])
a.sort()
k = 0
money = 0
q = a[0][0]
price = maxprice
for x in a:
    if q == x[0]:
        if price - x[1] >= 0:
            money += x[1]
            price -= x[1]
            k+=1
    else:
        price = maxprice
        q = x[0]
        if price - x[1] >= 0:
            money += x[1]
            price -= x[1]
            k+=1
print(k, money)