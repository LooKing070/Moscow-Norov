f = open("/Файлы для заданий/26_2650.txt", "r")
l, m, n = map(int, f.readline().split())
a = [0] * l
b = [list(map(int, x.split())) for x in f.readlines()]
for x in b:
    for q in range(x[0] - 1, x[0] + x[1]):
        a[q] += 1
st = 0
c = []
for x in range(l):
    if a[x-1] == 1 and a[x] == 0:
        st = x - 14
    if a[x-1] == 0 and a[x] == 1 or x == l - 1:
        if x - st >= m:
            c.append(x-st)
print(len(c),max(c))