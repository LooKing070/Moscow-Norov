f = open("/Users/andrej/Downloads/EGE-2024/26/art.txt")
k, n = map(int, f.readline().split())
pr = []
deneg = []
for q in range(k):
    pr.append(int(f.readline()))
for q in range(n):
    deneg.append(int(f.readline()))
pr.sort()
deneg.sort()
k = t = 0
while len(pr) >= 0:
    q = pr[0]
    deneg_= deneg.copy()
    for w in range(len(deneg)):
        if deneg[w] - q >= 0:
            deneg[w] -= q
            pr.pop(0)
            k += 1
            t += q
            deneg.sort()
            break
    if deneg_ == deneg: break
print(k, t)