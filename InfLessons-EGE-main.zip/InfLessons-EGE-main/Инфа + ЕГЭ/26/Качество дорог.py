f = open("/Файлы для заданий/26_2480.txt", "r")
n = int(f.readline())
a = [list(map(int, x.split())) for x in f.readlines()]
b = [0] * 1120000
for x in a:
    for q in range(x[0], x[1]):
        b[q] += 1
k = 0
dl = 0
st = 0
end = 0
for x in range(1,len(b)):
    if b[x] > 0:
        dl += 1
    if b[x] == 0 and b[x-1] > 0: k += 1
print(k,dl)