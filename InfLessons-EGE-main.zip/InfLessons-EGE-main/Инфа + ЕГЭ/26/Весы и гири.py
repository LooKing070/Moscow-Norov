f = open("/Файлы для заданий/26_2653.txt", "r")
n = int(f.readline())
a = [int(x) for x in f.readlines()]
a.sort()
w = [0] * (sum(a) + 1)
for x in a:
    w1 = w.copy()
    for i in range(sum(a) + 1):
        if w[i] == 1:
            w1[i + x] = 1
    w1[x] = 1
    w = w1
k = m = 0
for i in range(1, sum(a) + 1):
    if w[i] == 0:
        k += 1
        m = i
print(k, m)