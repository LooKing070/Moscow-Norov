f = open("/Users/andrej/Downloads/EGE-2024/26/screw.txt", "r")
n = int(f.readline())
a = {}
for x in f.readlines():
    q, w, e = map(str, x.split())
    if (f"{w} {e}" not in a):
        a[f"{w} {e}"] = int(q)
    else:
        a[f"{w} {e}"] += int(q)
s = 0
k = 0
for q in a:
    if a[q] < 50:
        k += 50 - a[q]
        s += (int(q.split()[0])*int(q.split()[1])*(50-a[q]))
print(k,s)