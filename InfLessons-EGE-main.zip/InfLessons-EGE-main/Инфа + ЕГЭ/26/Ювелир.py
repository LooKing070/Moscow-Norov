f = open("/Users/andrej/Downloads/EGE-2024/26/gem.txt", "r")
m, n = map(int, f.readline().split())
a = [int(x) for x in f]
a.sort()
k = 0
ma = 0
while m - a[0] >=0:
    k += 1
    m -= a[0]
    ma = a.pop(0)
mak = ma
for x in range(1, m +1):
    if ma + x in a:
        mak = ma + x
print(k, max(ma,mak))