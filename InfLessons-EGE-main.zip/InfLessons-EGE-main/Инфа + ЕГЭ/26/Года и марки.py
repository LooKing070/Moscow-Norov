f = open("/Файлы для заданий/26_2651.txt", "r")
n = int(f.readline())
a = {}
for x in f.readlines():
    q, w = map(int, x.split())
    if q not in a:
        a[q] = str(w)
    else:
        if str(w) not in a[q]:
            a[q] += str(w)
sorted(a)
k = 0
y = 0
m = 8
for x in a:
    if len(a[x])<8:
        k += (8 - len(a[x]))
        if len(a[x]) <= m:
            m = len(a[x])
            y = x
print(k, y)