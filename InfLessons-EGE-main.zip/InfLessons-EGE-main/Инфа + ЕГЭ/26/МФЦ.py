f = open("/Users/andrej/Downloads/EGE-2024/26/mfc.txt")
k = int(f.readline())
n = int(f.readline())
nach = 480
kon = 23 * 60
nesm = 0
a = [[0,0]] * k
b = []
for e in range(n):
    x = f.readline()
    q, w = x.split()
    vr = int(q.split(":")[0]) * 60 + int(q.split(":")[1])
    if vr >= nach and vr <= kon:
        b.append([vr, int(w)])
    else: nesm += 1
b.sort()
for x in b:
    e = []
    for w in a:
        e.append(x[0] - w[0])
    if a[e.index(max(e))][0] <= kon:
        a[e.index(max(e))] = [x[0] + x[1], a[e.index(max(e))][1] + 1]
    else: nesm += 1
print(a)
print(nesm)